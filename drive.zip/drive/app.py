from flask import Flask, render_template, request
from model import classifier, tweet_to_tensor

# Instanciate model
model = classifier()

# Upload wieghts
model.init_from_file('model.pkl.gz')

# Define application
app = Flask(__name__)

# Deine route for homepage
@app.route("/")

def index() : 
    return render_template('index.html')

@app.route("/predict", methods = ['POST'])
def predict() : 

	feature = [str(x) for x in request.form.values()]

	input = np.array(tweet_to_tensor(feature[0]))

	# Classification using model	
	pred, prob = model(input)

	return render_template('index.html', prediction_text='Disaster Twwet cioncern a {} with a probability of {}%'.format(bool(pred), round(prob*100,2)))

if __name__ == "__main__" : 
    app.run(debug = True)